// const toggleButton = document.getElementById('theme-toggle');
// const body = document.body;

// toggleButton.addEventListener('click', function() {
//   if (body.classList.contains('light-theme')) {
//     body.classList.replace('light-theme', 'dark-theme');
//   } else {
//     body.classList.replace('dark-theme', 'light-theme');
//   }
// });
var tablinks = document.getElementsByClassName("tablinks");
var tabcontent = document.getElementsByClassName("tabcontent");

function opentab(tabname) {
    // Remove activelink from all tab links
    for (let tablink of tablinks) {
        tablink.classList.remove("activelink");
    }
    
    // Hide all tab content by removing activetab
    for (let content of tabcontent) {
        content.classList.remove("activetab");
    }

    // Add activelink to the clicked tab
    event.currentTarget.classList.add("activelink");

    // Show the corresponding tab content by adding activetab
    document.getElementById(tabname).classList.add("activetab");
}

// Initialize ScrollReveal
    ScrollReveal().reveal('.headertext', {
        delay: 300,  // Delay in milliseconds
        distance: '50px',  // Distance to move the element
        origin: 'top',  // Direction of reveal (top, bottom, left, right)
        duration: 1000,  // Duration of animation in milliseconds
        easing: 'ease-in-out',  // Animation easing
        reset: true  // Animation will reset when you scroll back up
    });

    ScrollReveal().reveal('.aboutcol1', {
        delay: 200,
        distance: '50px',
        origin: 'left',
        duration: 1000
    });

    ScrollReveal().reveal('.aboutcol2', {
        delay: 300,
        distance: '50px',
        origin: 'right',
        duration: 1000
    });

    ScrollReveal().reveal('.serviceslist div', {
        delay: 300,
        distance: '50px',
        origin: 'bottom',
        interval: 200  // Delay between each revealing element
    });

    ScrollReveal().reveal('.contactleft', {
        delay: 400,
        distance: '50px',
        origin: 'left',
        duration: 1000
    });

    ScrollReveal().reveal('.contactright', {
        delay: 500,
        distance: '50px',
        origin: 'right',
        duration: 1000
    });