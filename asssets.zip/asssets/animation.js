// Initialize ScrollReveal
ScrollReveal().reveal('.headertext', {
    delay: 200,  // Delay in milliseconds
    distance: '50px',  // Distance to move the element
    origin: 'top',  // Direction of reveal (top, bottom, left, right)
    duration: 1000,  // Duration of animation in milliseconds
    easing: 'ease-in-out',  // Animation easing
    reset: true  // Animation will reset when you scroll back up
});

ScrollReveal().reveal('.aboutcol1', {
    delay: 300,
    distance: '50px',
    origin: 'left',
    duration: 1000
});

ScrollReveal().reveal('.aboutcol2', {
    delay: 400,
    distance: '50px',
    origin: 'right',
    duration: 1000
});

ScrollReveal().reveal('.serviceslist div', {
    delay: 500,
    distance: '50px',
    origin: 'bottom',
    interval: 200  // Delay between each revealing element
});

ScrollReveal().reveal('.contactleft', {
    delay: 400,
    distance: '50px',
    origin: 'left',
    duration: 1000
});

ScrollReveal().reveal('.contactright', {
    delay: 500,
    distance: '50px',
    origin: 'right',
    duration: 1000
});